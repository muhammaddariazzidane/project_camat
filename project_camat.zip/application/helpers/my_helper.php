<?php

function is_logged_in()
{
  $ci = get_instance();
  if (!$ci->session->nama) {
    redirect('login');
  }
}
